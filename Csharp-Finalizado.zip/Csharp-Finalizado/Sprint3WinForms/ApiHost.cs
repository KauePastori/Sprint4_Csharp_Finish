using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Sprint3WinForms.Data;

namespace Sprint3WinForms.Api
{
    public class ApiHost
    {
        public async Task StartAsync()
        {
            var builder = WebApplication.CreateBuilder();

            builder.Services.AddDbContext<AppDbContext>(opt =>
                opt.UseSqlite($"Data Source={Path.Combine(AppContext.BaseDirectory, "app.db")}"));
            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            using (var scope = app.Services.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                db.Database.EnsureCreated();
                Seed.TrySeed(db);
            }

            app.UseSwagger();
            app.UseSwaggerUI();

            app.MapControllers();

            // Executa em porta fixa para facilitar avaliação
            app.Urls.Clear();
            app.Urls.Add("http://localhost:5199");

            _ = app.RunAsync();
            await Task.CompletedTask;
        }
    }
}
