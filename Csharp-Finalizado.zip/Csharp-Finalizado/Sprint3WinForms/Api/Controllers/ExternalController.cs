using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;

namespace Sprint3WinForms.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ExternalController : ControllerBase
    {
        private readonly HttpClient _http = new HttpClient();

        // Exemplo 1: ViaCEP (API pública brasileira)
        [HttpGet("cep/{cep}")]
        public async Task<IActionResult> Cep(string cep)
        {
            var url = $"https://viacep.com.br/ws/{cep}/json/";
            var result = await _http.GetFromJsonAsync<object>(url);
            return Ok(result);
        }

        // Exemplo 2: Chuck Norris jokes (para demonstrar integração)
        [HttpGet("joke")]
        public async Task<IActionResult> Joke()
        {
            var result = await _http.GetFromJsonAsync<object>("https://api.chucknorris.io/jokes/random");
            return Ok(result);
        }
    }
}
