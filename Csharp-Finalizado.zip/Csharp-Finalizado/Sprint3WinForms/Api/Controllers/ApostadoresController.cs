using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sprint3WinForms.Data;
using Sprint3WinForms.Models;

namespace Sprint3WinForms.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ApostadoresController : ControllerBase
    {
        private readonly AppDbContext _db;
        public ApostadoresController(AppDbContext db) => _db = db;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Apostador>>> GetAll()
            => Ok(await _db.Apostadores.OrderBy(a => a.Id).ToListAsync());

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Apostador>> GetById(int id)
        {
            var a = await _db.Apostadores.FindAsync(id);
            return a is null ? NotFound() : Ok(a);
        }

        [HttpPost]
        public async Task<ActionResult<Apostador>> Create([FromBody] Apostador entity)
        {
            _db.Apostadores.Add(entity);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = entity.Id }, entity);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] Apostador dto)
        {
            var a = await _db.Apostadores.FindAsync(id);
            if (a is null) return NotFound();

            a.Nome = dto.Nome;
            a.Saldo = dto.Saldo;
            a.DataCadastro = dto.DataCadastro;
            await _db.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var a = await _db.Apostadores.FindAsync(id);
            if (a is null) return NotFound();
            _db.Remove(a);
            await _db.SaveChangesAsync();
            return NoContent();
        }

        // LINQ: filtro por saldo mínimo + top N
        [HttpGet("top")]
        public async Task<ActionResult<IEnumerable<Apostador>>> GetTop([FromQuery] decimal minSaldo = 0, [FromQuery] int take = 5)
        {
            var query = _db.Apostadores
                .Where(a => a.Saldo >= minSaldo)
                .OrderByDescending(a => (double)a.Saldo) // cast para contornar ORDER BY decimal no SQLite
                .Take(take);

            return Ok(await query.ToListAsync());
        }

        // LINQ: busca por nome (contém)
        [HttpGet("search")]
        public async Task<ActionResult<IEnumerable<Apostador>>> Search([FromQuery] string q)
        {
            if (string.IsNullOrWhiteSpace(q)) return BadRequest("Informe 'q'.");
            var list = await _db.Apostadores
                .Where(a => a.Nome.ToLower().Contains(q.ToLower()))
                .OrderBy(a => a.Nome)
                .ToListAsync();
            return Ok(list);
        }

        // LINQ: métricas simples
        [HttpGet("stats")]
        public async Task<ActionResult<object>> Stats()
        {
            var count = await _db.Apostadores.CountAsync();
            var total = await _db.Apostadores.SumAsync(a => a.Saldo);
            var avg = count == 0 ? 0 : await _db.Apostadores.AverageAsync(a => (double)a.Saldo);
            return Ok(new { count, total, avg });
        }
    }
}
