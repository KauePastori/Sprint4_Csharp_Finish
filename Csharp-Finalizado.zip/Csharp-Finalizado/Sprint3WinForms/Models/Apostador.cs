using System;
using System.ComponentModel.DataAnnotations;

namespace Sprint3WinForms.Models
{
    public class Apostador
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Nome { get; set; } = string.Empty;

        [Required]
        public decimal Saldo { get; set; }

        [Required]
        public DateTime DataCadastro { get; set; } = DateTime.UtcNow;
    }
}
