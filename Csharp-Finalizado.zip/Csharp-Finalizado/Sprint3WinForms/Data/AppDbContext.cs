using Microsoft.EntityFrameworkCore;
using Sprint3WinForms.Models;

namespace Sprint3WinForms.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Apostador> Apostadores => Set<Apostador>();
    }

    public static class Seed
    {
        public static void TrySeed(AppDbContext db)
        {
            if (db.Apostadores.Any()) return;

            db.Apostadores.AddRange(new[]
            {
                new Apostador { Nome = "Alice", Saldo = 150.25m, DataCadastro = DateTime.UtcNow.AddDays(-7) },
                new Apostador { Nome = "Bruno", Saldo = 89.99m, DataCadastro = DateTime.UtcNow.AddDays(-2) },
                new Apostador { Nome = "Carla", Saldo = 250.00m, DataCadastro = DateTime.UtcNow.AddDays(-1) },
            });
            db.SaveChanges();
        }
    }
}
