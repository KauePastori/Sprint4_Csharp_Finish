using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace Sprint3WinForms.Ui
{
    public class MainForm : Form
    {
        private readonly LinkLabel link = new LinkLabel();
        private readonly Label status = new Label();
        public MainForm()
        {
            Text = "Sprint4 - WinForms + Web API (Swagger)";
            Width = 680; Height = 180;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            link.Text = "Abrir Swagger";
            link.Left = 20; link.Top = 60; link.AutoSize = true;
            link.LinkClicked += (s, e) => Process.Start(new ProcessStartInfo { FileName = "http://localhost:5199/swagger", UseShellExecute = true });

            status.Text = "API hospedada em http://localhost:5199";
            status.Left = 20; status.Top = 20; status.AutoSize = true;

            Controls.Add(status);
            Controls.Add(link);
        }
    }
}
